

#ifndef __BLINKY_H
#define __BLINKY_H
void test_led(void);
#define TEST_LED (1 << 10)

#endif
