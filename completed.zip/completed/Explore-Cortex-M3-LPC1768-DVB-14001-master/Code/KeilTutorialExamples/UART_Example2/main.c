#include <stdio.h>
#include "uart.h"
#include "spi.h"
#include "gpio.h"

#define PSH(X) (*(buf++)=(X))
#define PSH1(X) (*(buf--)=(X))
#define PEEK() buf[-1]
#define POP() *(--buf) = '\0'

#define PLUS 1
#define SPACE 2
uint8_t dummy_u8;
uint8_t data[]="";

char * gcvt(double f, size_t ndigit, char * buf);


int main()
{
	char *a;
	char array[150];
	float x=3.4545;
    SystemInit();
	UART0_Init(9600); 

	
    /* Initialize All the Four UARTs with different Baud rate */
     
    

    while(1)
    {
		 
		
		sprintf(array, "%f", 3.123);
		UART0_Printf(array); 
	    UART0_Printf("Welcome to LPC1768 UART Programming on channel One at 9600 baud\n\r"); 
        UART1_Printf("Welcome to LPC1768 UART Programming on channel One at 19200 baud\n\r"); 
        UART2_Printf("Welcome to LPC1768 UART Programming on channel Two at 38400 baud\n\r"); 
        UART3_Printf("Welcome to LPC1768 UART Programming on channel Three at 115200 baud\n\r"); 
		
	//	a=gcvt(x, 6, array);
	//	UART0_Printf(a);
		
    }
}