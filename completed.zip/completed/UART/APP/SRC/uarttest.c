/*****************************************************************************
 *   uarttest.c:  main C entry file for NXP LPC17xx Family Microprocessors
 *
 *   Copyright(C) 2009, NXP Semiconductor
 *   All rights reserved.
 *
 *   History
 *   2009.05.27  ver 1.00    Prelimnary version, first Release
 *
******************************************************************************/
#include "lpc17xx.h"
#include "uart.h"
#include "spi.h"
#include "gpio.h"

extern volatile uint32_t UART3Count;
extern volatile uint8_t UART3Buffer[BUFSIZE];
extern volatile uint32_t UART2Count;
extern volatile uint8_t UART2Buffer[BUFSIZE];
extern volatile uint32_t UART1Count;
extern volatile uint8_t UART1Buffer[BUFSIZE];
extern volatile uint32_t UART0Count;
extern volatile uint8_t UART0Buffer[BUFSIZE];
void send_command(unsigned char *data);
void getreply(void);
void delay(int a);
/*****************************************************************************
**   Main Function  main()
This program has been test on Keil LPC1700 board.
*****************************************************************************/
int main (void)
{
	SystemInit();
	SPI_Init();
	UARTInit(0, 9600);
	UARTInit(1, 9600);	/* baud rate setting */
	 
	 	
	delay(1000);
	while(1){
		uint8_t=SPI_Read();
		UARTSend( 0, uint8_t, sizeof(uint8_t));		  	
	}																  
}

void send_command(unsigned char *data){
	UARTSend( 1, data, sizeof(data) );
	getreply();
	return;	
}

void getreply(){
 while (1) 
  {				/* Loop forever */
	
	
	if ( UART0Count != 0 )
	{
	  LPC_UART1->IER = IER_THRE | IER_RLS;			/* Disable RBR */
	  UARTSend( 1, (uint8_t *)UART0Buffer, UART0Count );
	  UART0Count = 0;
	  LPC_UART1->IER = IER_THRE | IER_RLS | IER_RBR;	/* Re-enable RBR */
	  break;
	}

   	else if ( UART1Count != 0 )
	{
	  LPC_UART0->IER = IER_THRE | IER_RLS;			/* Disable RBR */
	  UARTSend( 0, (uint8_t *)UART1Buffer, UART1Count );
	  UART1Count = 0;
	  LPC_UART0->IER = IER_THRE | IER_RLS | IER_RBR;	/* Re-enable RBR */
	   break;
	}
/*	else{
		UARTSend( 0, "no", 3 );
	}						  */
  }
  return;

}



void SPI_Init(void)
{    
    GPIO_PinFunction(SCK_PIN,SPI_FUNCTION);   /* Configure the Pinfunctions for SPI */
    GPIO_PinFunction(MOSI_PIN,SPI_FUNCTION);
    GPIO_PinFunction(MISO_PIN,SPI_FUNCTION);
    GPIO_PinFunction(SSEL_PIN,PINSEL_FUNC_0); /* Configure the SSEL pin as GPIO */

    GPIO_PinDirection(SCK_PIN,OUTPUT);        /* Configure SCK,MOSI,SSEl as Output and MISO as Input */ 
    GPIO_PinDirection(MOSI_PIN,OUTPUT);
    GPIO_PinDirection(MISO_PIN,INPUT);
    GPIO_PinDirection(SSEL_PIN,OUTPUT);

    SPI_DisableChipSelect();                  /* Disable the Slave Select */

    LPC_SC->PCONP |= (1 << 8);                   /* enable power to spi clock */

    LPC_SPI->SPCCR = spi_GetPclk()/SCK_Freq;  /* Set Spi Clock */     

    LPC_SPI->SPCR = ((0<<SBIT_CPHA) | (1<<SBIT_CPOL) | (1<<SBIT_MSTR));
    dummy_u8  = LPC_SPI->SPSR;               /* Dummy read to clear the flags */
    dummy_u8  = LPC_SPI->SPDR;               /* Dummy read to clear the flags */
}





/***************************************************************************************************
                          uint8_t SPI_Write (uint8_t spiData_u8)
 ****************************************************************************************************
 * I/P Arguments : 
                 uint8_t : Byte of data to be send on SPI.

 * Return value  : 
                 uint8_t : Returns back the data send on SPI, this is used in case of SD card.

 * description :
                 This function is used to send a byte of data through SPI.              
 ****************************************************************************************************/
uint8_t SPI_Write (uint8_t spiData_u8)
{
    LPC_SPI->SPDR = spiData_u8;
    while(util_GetBitStatus(LPC_SPI->SPSR,SBIT_SPIF) == 0); /* wait until data is sent */
    dummy_u8 = LPC_SPI->SPSR;
    dummy_u8 = LPC_SPI->SPDR;

    return spiData_u8;
}






/***************************************************************************************************
                          uint8_t SPI_Read(void)
 ****************************************************************************************************
 * I/P Arguments : none

 * Return value  : 
                  uint8_t : Returns back a byte of data read from SPI.

 * description :
                 This function is used to read a byte of data from SPI.              
 ****************************************************************************************************/
uint8_t SPI_Read(void)
{
    uint8_t spiData_u8;

    LPC_SPI->SPDR = 0xff;

    while(util_GetBitStatus(LPC_SPI->SPSR,SBIT_SPIF) == 0); /* wait until data is received */
    dummy_u8 = LPC_SPI->SPSR;                               /* Dummy read to clear the flags */
    spiData_u8 = (uint8_t)LPC_SPI->SPDR; 

    return spiData_u8;
}






/***************************************************************************************************
                    static uint32_t spi_GetPclk(void)
 ****************************************************************************************************
 * I/P Arguments : none

 * Return value  : 
                  uint32_t : SPI clock frequency set in PCLKSEL register.

 * description :
                 This function is used to determine the pclk value for SPI.              
 ****************************************************************************************************/
static uint32_t spi_GetPclk(void)
{
    uint32_t v_spiPclk_u32,v_Pclk_u32;
    /**
       PCLKSELx registers contains the PCLK info for all the clock dependent peripherals.
       Bit16,Bit17 contains the SPI Clock(ie.SPI_PCLK) information.
       The SPI_PCLK and the actual Peripheral Clock(PCLK) is calculated as below.
       (Refer data sheet for more info)

       SPI_PCLK    PCLK
         0x00       SystemFreq/4        
         0x01       SystemFreq
         0x02       SystemFreq/2
         0x03       SystemFreq/8   
     **/

    v_spiPclk_u32 = (LPC_SC->PCLKSEL0 >> 16) & 0x03;

    switch( v_spiPclk_u32 )
    {
    case 0x00:
        v_Pclk_u32 = SystemCoreClock/4;           //SystemFrequency or  SystemCoreClock
        break;
    case 0x01:
        v_Pclk_u32 = SystemCoreClock;
        break;
    case 0x02:
        v_Pclk_u32 = SystemCoreClock/2;
        break;
    case 0x03:
        v_Pclk_u32 = SystemCoreClock/8;
        break;
    }

    return (v_Pclk_u32);
}



void delay(int a){
	int i,j;
	for(i=0;i<=a;i++)
	{
		for(j=i;j<=35;j++)
		{
		}
	}
}

/*****************************************************************************
**                            End Of File
*****************************************************************************/
