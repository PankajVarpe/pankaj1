/*****************************************************************************
 *   uarttest.c:  main C entry file for NXP LPC17xx Family Microprocessors
 *
 *   Copyright(C) 2009, NXP Semiconductor
 *   All rights reserved.
 *
 *   History
 *   2009.05.27  ver 1.00    Prelimnary version, first Release
 *
******************************************************************************/
#include "lpc17xx.h"
#include "type.h"
#include "uart.h"

#include "string.h"

extern volatile uint32_t UART3Count;
extern volatile uint8_t UART3Buffer[BUFSIZE];
extern volatile uint32_t UART2Count;
extern volatile uint8_t UART2Buffer[BUFSIZE];
extern volatile uint32_t UART1Count;
extern volatile uint8_t UART1Buffer[BUFSIZE];
extern volatile uint32_t UART0Count;
extern volatile uint8_t UART0Buffer[BUFSIZE];

void send_command(unsigned char *data);
int getreply(void);
void delay_ms(int a),init_esp(),connectrouter1(),connectrouter2(),mux(),server(),senddata(),clear_sting(unsigned char *str, unsigned int val ),client(),operationmode(),receivedata(),ledon();
signed int tp_strcmp( unsigned char *s1, unsigned char *s2);
unsigned char string_rec[20];
unsigned char machine_num[50];
void senddata(void);
void disconnectwifi();

/*****************************************************************************
**   Main Function  main()
This program has been test on Keil LPC1700 board.
*****************************************************************************/
int main (void)
{
	unsigned short int i;
	
	SystemInit();
	LPC_GPIO0->FIODIR |= (1<<4); 
 	LPC_GPIO0->FIOCLR |= (1<<4);
 	init_esp();
//	disconnectwifi();
  	operationmode();	 
	i=getreply();  	

 		while (1) 
			{				/* Loop forever */
			switch(i) {
					case 1  :
										ledon();
										i=getreply();
										continue;
   				 							 
					case 2  : 			connectrouter1();
										i=getreply();
										continue;

					case 3  :			connectrouter2();
										i=getreply();
										continue;
					
					}	
			}																	  
}


void init_esp(){
	unsigned short int i,j;
	unsigned char data_rcv[3];
	clear_sting(UART1Buffer,UART1Count);
	UARTInit(0, 9600); /* uart0 */
  	UARTInit(1, 9600);	/* baud rate setting for esp */
   	UARTSend( 0, "wait", 4);
	UARTSend( 1, "ATE0\r\n", sizeof("ATE0\r\n"));	
 	delay_ms(300);
	clear_sting(UART1Buffer,UART1Count);
	UARTSend( 0, (uint8_t *)UART1Buffer, UART1Count );

	UARTSend( 1, "AT\r\n", sizeof("AT\r\n"));	
 	delay_ms(300); 
	UARTSend( 0, (uint8_t *)UART1Buffer, UART1Count );
	i=0;

	while(UART1Buffer[i++] != 'O');
//	data_rcv[0]='O';
//	data_rcv[1]='K';
//	
//	data_rcv[2]='\0';
	i--;
	for(j=0;j<2;j++)
	{
	 	data_rcv[j]= UART1Buffer[i++];
	}
	data_rcv[j]='\0';
	UARTSend( 0, (uint8_t *)data_rcv, sizeof(data_rcv) );
	if((tp_strcmp((uint8_t *)data_rcv,"OK")) == 0)
		{
			UARTSend( 0, "Initialiize",9 );	
		}
		else
		{
			UARTSend( 0, "Initialiize unsuccess", 18 );
		}
	return;
}

void disconnectwifi(){
	unsigned short int i,j;
	unsigned char data_rcv[11];

	clear_sting(UART1Buffer,UART1Count);

	UARTSend( 1, "AT+CWQAP\r\n", sizeof("AT+CWQAP\r\n"));	 //DISCONNECT CURRENT WIFI
	delay_ms(1000); 

	i=0;

	while(UART1Buffer[i++] != 'D');
//	data_rcv[0]='O';
//	data_rcv[1]='K';
//	
//	data_rcv[2]='\0';
	i--;
	for(j=0;j<10;j++)
	{
	 	data_rcv[j]= UART1Buffer[i++];
	}
	data_rcv[j]='\0';
	UARTSend( 0, (uint8_t *)data_rcv, sizeof(data_rcv) );
	if((tp_strcmp((uint8_t *)data_rcv,"DISCONNECT")) == 0)
		{
		   	UARTSend( 0, "DISCONNCTED",11 );	
			return;	
			
		}
		else
		{
			return;
		}

}

void operationmode(){
	unsigned short int i,j;
	unsigned char data_rcv[3];

	clear_sting(UART1Buffer,UART1Count);
	UARTSend( 1, "AT+CWMODE=1\r\n", sizeof("AT+CWMODE=1\r\n"));
	delay_ms(300);
	i=0;

	while(UART1Buffer[i++] != 'O');

	i--;
	for(j=0;j<2;j++)
	{
	 	data_rcv[j]= UART1Buffer[i++];
	}
	data_rcv[j]='\0';
	UARTSend( 0, (uint8_t *)data_rcv, sizeof(data_rcv) );
	if((tp_strcmp((uint8_t *)data_rcv,"OK")) == 0)
		{
			UARTSend( 0, "MODE 1", 6 );
		}
	return;	
}


void connectrouter1(){
	unsigned short int i,j;
	unsigned char data_rcv[10];
	clear_sting(UART1Buffer,UART1Count);			
	UARTSend( 1, "AT+CWJAP=\"TMS1\",\"\"\r\n", sizeof("AT+CWJAP=\"TMS1\",\"\"\r\n"));	   //change ssid as per the machines
  	delay_ms(5000);
	i=0;
	while(UART1Buffer[i++] != 'C');

	i--;
	for(j=0;j<9;j++)
	{
	 	data_rcv[j]= UART1Buffer[i++];
	}
	data_rcv[j]='\0';
	UARTSend( 0, (uint8_t *)data_rcv, sizeof(data_rcv) );
	if((tp_strcmp((uint8_t *)data_rcv,"CONNECTED")) == 0)
			{				
				client();
			}

		else
			{
				connectrouter1();	
			}
			return;	
}	


void connectrouter2(){
	unsigned short int i,j;
	unsigned char data_rcv[10];
	clear_sting(UART1Buffer,UART1Count);

	UARTSend( 1, "AT+CWJAP=\"TMS2\",\"\"\r\n", sizeof("AT+CWJAP=\"TMS2\",\"\"\r\n"));	   //change ssid as per the machines
 	delay_ms(5000);
	i=0;
	while(UART1Buffer[i++] != 'C');

	i--;
	for(j=0;j<9;j++)
	{
	 	data_rcv[j]= UART1Buffer[i++];
	}
	data_rcv[j]='\0';
	UARTSend( 0, (uint8_t *)data_rcv, sizeof(data_rcv) );
	if((tp_strcmp((uint8_t *)data_rcv,"CONNECTED")) == 0)
			{
				
				client();
			}
			else
			{
				
			}
			return;	
}	


void client(){
	unsigned short int i,j;
	unsigned char data_rcv[8];
	clear_sting(UART1Buffer,UART1Count);
	clear_sting(string_rec,sizeof(string_rec));
	UARTSend( 1, "AT+CIPSTART=\"TCP\",\"192.168.4.1\",139\r\n",sizeof("AT+CIPSTART=\"TCP\",\"192.168.4.1\",139\r\n"));
	delay_ms(1000);

	UARTSend( 0, (uint8_t *)UART1Buffer, UART1Count );
	i=0;

	while(UART1Buffer[i++] != 'C');
//	data_rcv[0]='O';
//	data_rcv[1]='K';
//	
//	data_rcv[2]='\0';
	i--;
	for(j=0;j<7;j++)
	{
	 	data_rcv[j]= UART1Buffer[i++];
	}
	data_rcv[j]='\0';
	UARTSend( 0, (uint8_t *)data_rcv, sizeof(data_rcv) );
	if((tp_strcmp((uint8_t *)data_rcv,"CONNECT")) == 0)
			{
				UARTSend( 0, "setted as client", 16 );
				delay_ms(500);
				senddata();
				return;		
			}
	
}


void send_command(unsigned char *data){
	UARTSend( 1, data, sizeof(data) );
	return;	
}

void ledon(){

    LPC_GPIO0->FIOSET |= (1<<4); 
	return;	
}

void senddata(){
   	unsigned short int i,j;
	unsigned char data_rcv[3];	
	clear_sting(string_rec,sizeof(string_rec));
	clear_sting(UART1Buffer,UART1Count);
	UART1Count=0; 
	UARTSend( 0, "sending data", 13);
	delay_ms(1500);
	UARTSend( 1, "AT+CIPSEND=5\r\n", sizeof("AT+CIPSEND=5\r\n"));

	delay_ms(500);

	UARTSend( 0, (uint8_t *)UART1Buffer, UART1Count );
	i=0;

	while(UART1Buffer[i++] != '>');


	
	i--;
	for(j=0;j<1;j++)
	{
	 	data_rcv[j]= UART1Buffer[i++];
	}
	data_rcv[j]='\0';
	UARTSend( 0, (uint8_t *)data_rcv, sizeof(data_rcv) );
	if((tp_strcmp((uint8_t *)data_rcv,">")) == 0)
			{
				UARTSend( 1, "START\r\n", sizeof("START\r\n"));
			}
		else
			{
				UARTSend( 0, "DATA NOT SENT to client", 23 );
				senddata();
			}
	return;
}
signed int tp_strcmp( unsigned char *s1, unsigned char *s2)
	{
   		for (; *s1 == *s2; s1++, s2++)
      		if (*s1 == '\0')
         	return(0);
   		return((*s1 < *s2) ? -1: 1);
	}

void clear_sting(unsigned char *str, unsigned int val ){
	int i = 0 ;
     for( i = 0 ; i < val ; i++ )
     {
          str[i] = '\0' ;
     }
	 return ;
}



int getreply(){
	unsigned short int i,j;
	unsigned char data_rcv[6];
	UART0Count=0;
	clear_sting(UART0Buffer,25);
 	while (1) 
 	 {				/* Loop forever */
 	 delay_ms(300);

  	UARTSend( 0, (uint8_t *)UART0Buffer, UART0Count );
	i=0;

	while(UART0Buffer[i++] != 'S');

	i--;
	for(j=0;j<7;j++)
	{
	 	data_rcv[j]= UART0Buffer[i++];
	}
	data_rcv[j]='\0';
	UARTSend( 0, (uint8_t *)data_rcv, sizeof(data_rcv) );

	if((tp_strcmp((uint8_t *)data_rcv,"START:1")) == 0)
			{

				return 1;
			}
		else if((tp_strcmp((uint8_t *)data_rcv,"START:2")) == 0)
			{
				disconnectwifi();
			 	return 2;
			}

		else if((tp_strcmp((uint8_t *)data_rcv,"START:3")) == 0)
			{
				disconnectwifi();
			 	return 3;
			}
  	}

}
void delay_ms(int a){
	int i,j;
	for(i = 0 ; i < a ; i++ )
	{
		for(j = 0 ; j < 10000 ; j++ ) ;
	}
	return ;
}



/*****************************************************************************
**                            End Of File
*****************************************************************************/
