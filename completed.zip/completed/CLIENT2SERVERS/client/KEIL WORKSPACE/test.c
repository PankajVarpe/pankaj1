/*****************************************************************************
 *   uarttest.c:  main C entry file for NXP LPC17xx Family Microprocessors
 *
 *   Copyright(C) 2009, NXP Semiconductor
 *   All rights reserved.
 *
 *   History
 *   2009.05.27  ver 1.00    Prelimnary version, first Release
 *
******************************************************************************/
#include "lpc17xx.h"
#include "type.h"
#include "uart.h"
#define LED (1 << 29)

extern volatile uint32_t UART0Count;
extern volatile uint8_t UART0Buffer[BUFSIZE];

signed int tp_strcmp( unsigned char *s1, unsigned char *s2)
{
   for (; *s1 == *s2; s1++, s2++)
      if (*s1 == '\0')
         return(0);
   return((*s1 < *s2) ? -1: 1);
}

void delay_ms( int val)
{
	int i;
	int j;
	for(i = 0 ; i < val ; i++ )
	{
		for(j = 0 ; j < 10000 ; j++ ) ;
	}
	return ;
}

void clear_sting(unsigned char *str )
{
	int i = 0 ;
     for( i = 0 ; str[i] != '\0' ; i++ )
     {
          str[i] = '\0' ;
     }
	 return ;
}

/*****************************************************************************
**   Main Function  main()
This program has been test on Keil LPC1700 board.
*****************************************************************************/
int main (void)
{
	unsigned char insert_num[20],tool_num[3],status[6];
	unsigned int tool_val,i,j;
	unsigned char machine_num[5];
	
	SystemInit();
	
	UARTInit(0, 9600);
													  
	LPC_GPIO1->FIODIR   |=  LED;				// P1.29 = Outputs 
	LPC_GPIO1->FIOCLR 	 =  LED;				// Turn-OFF LED

	

	while (1) 
	{				/* Loop forever */
	
		UART0Count=0; 
		
		while(UART0Count == 0 );
		
		i=0;
		while(UART0Buffer[0]!='.'  )
		{
			if(UART0Count == 1)
			{
				LPC_UART0->IER = IER_THRE | IER_RLS;			/* Disable RBR */
				insert_num[i++]=UART0Buffer[0];
				
				UART0Count=0;
				LPC_UART0->IER = IER_THRE | IER_RLS | IER_RBR;	/* Re-enable RBR */	
			}				
		}
		insert_num[i]='\0';
		i=0;
		j=0;
		//UARTSend( 0, UART0Buffer, sizeof(UART0Buffer));
		while(insert_num[i++]!=':');
		
		while(insert_num[i]!='.')
		{
			machine_num[j++]=insert_num[i];
			i++;
		}
		machine_num[j]='\0';	
		
		if((tp_strcmp(machine_num,"INIT")) == 0)
		{
		
			delay_ms(1000);
			UARTSend( 0, ":0.", sizeof(":0."));
			LPC_GPIO1->FIOSET 	 =  LED;
			break;		
		} 	
	}

	while(1)
	{
		UART0Count=0;

		clear_sting(machine_num);

		clear_sting(insert_num);
		 		
		while(UART0Count == 0 );

		i=0;
		while(UART0Buffer[0]!='.'  )
		{
			if(UART0Count == 1)
			{
				LPC_UART0->IER = IER_THRE | IER_RLS;			/* Disable RBR */
				insert_num[i++]=UART0Buffer[0];
				UART0Count=0;
				LPC_UART0->IER = IER_THRE | IER_RLS | IER_RBR;	/* Re-enable RBR */	
			 }				
		}
		insert_num[i]='\0';

	
		i=0;
		j=0;
		
		while(insert_num[i++]!=':');

		for(j=0;j<4;j++)
		{
			machine_num[j]=insert_num[i];
			i++;	
		}
		if((tp_strcmp(machine_num,"INIT")) == 0)
		{ 											
			delay_ms(1000);
			UARTSend( 0, ":0.", sizeof(":0."));						
		}		
		else
		{ 	  			  

			clear_sting(machine_num);
			
			i=0;
			j=0;
			
			while(insert_num[i++]!=':');
			
			while(insert_num[i]!=',')
			{
				machine_num[j++]=insert_num[i];
				i++;
			}
			machine_num[j]='\0';
	
			
		
	
			if((tp_strcmp(machine_num,"NEW")) == 0)
			{
				

				delay_ms(1000);
				UARTSend( 0, ":NEW0.", sizeof(":NEW0."));
				
				UART0Count=0; 
		
				while(UART0Count == 0 );
				
				i=0;
				while(UART0Buffer[0]!='.'  )
				{
					if(UART0Count == 1)
					{
						LPC_UART0->IER = IER_THRE | IER_RLS;			/* Disable RBR */
						insert_num[i++]=UART0Buffer[0];
						
						UART0Count=0;
						LPC_UART0->IER = IER_THRE | IER_RLS | IER_RBR;	/* Re-enable RBR */	
					}				
				}
				insert_num[i]='\0';
				i=0;
				j=0;
				//UARTSend( 0, UART0Buffer, sizeof(UART0Buffer));
				while(insert_num[i++]!=':');
				
				for(j=0;j<4;j++)
				{
					machine_num[j]=insert_num[i];
					i++;	
				}
				machine_num[j]='\0';	
				
				if((tp_strcmp(machine_num,"HPRI")) == 0)
				{
				
					delay_ms(1000);
					
					LPC_GPIO1->FIOCLR 	 =  LED;		
				}
				else if((tp_strcmp(machine_num,"LPRI")) == 0)
				{
				
					delay_ms(1000);
					
					LPC_GPIO1->FIOCLR 	 =  LED;		
				}
				else if((tp_strcmp(machine_num,"MPTY")) == 0)
				{
				
					delay_ms(1000);
					
					LPC_GPIO1->FIOCLR 	 =  LED;		
				}
				else if((tp_strcmp(machine_num,"EXIT")) == 0)
				{
				
					delay_ms(1000);
					
					LPC_GPIO1->FIOCLR 	 =  LED;		
				} 														
			} 
			else if((tp_strcmp(machine_num,"REP")) == 0)
			{
				

				delay_ms(5000);
				UARTSend( 0, ":REP.", sizeof(":REP."));

				delay_ms(5000);
				UARTSend( 0, ":REP0.", sizeof(":REP0."));

				
				UART0Count=0; 
		
				while(UART0Count == 0 );
				
				i=0;
				while(UART0Buffer[0]!='.'  )
				{
					if(UART0Count == 1)
					{
						LPC_UART0->IER = IER_THRE | IER_RLS;			/* Disable RBR */
						insert_num[i++]=UART0Buffer[0];
						
						UART0Count=0;
						LPC_UART0->IER = IER_THRE | IER_RLS | IER_RBR;	/* Re-enable RBR */	
					}				
				}
				insert_num[i]='\0';
				i=0;
				j=0;
				//UARTSend( 0, UART0Buffer, sizeof(UART0Buffer));
				while(insert_num[i++]!=':');
				
					for(j=0;j<4;j++)
				{
					machine_num[j]=insert_num[i];
					i++;	
				}
				machine_num[j]='\0';	
				
				if((tp_strcmp(machine_num,"HPRI")) == 0)
				{
				
					delay_ms(1000);
					
					LPC_GPIO1->FIOCLR 	 =  LED;		
				}
				else if((tp_strcmp(machine_num,"LPRI")) == 0)
				{
				
					delay_ms(1000);
					
					LPC_GPIO1->FIOCLR 	 =  LED;		
				}
				else if((tp_strcmp(machine_num,"MPTY")) == 0)
				{
				
					delay_ms(1000);
					
					LPC_GPIO1->FIOCLR 	 =  LED;		
				}
				else if((tp_strcmp(machine_num,"EXIT")) == 0)
				{
				
					delay_ms(1000);
					
					LPC_GPIO1->FIOCLR 	 =  LED;		
				} 														
			}
			else if((tp_strcmp(machine_num,"SUR")) == 0)
			{
				

				delay_ms(5000);
				UARTSend( 0, ":SUR.", sizeof(":SUR."));
				
					delay_ms(5000);
				UARTSend( 0, ":SUR0.", sizeof(":SUR0."));

																	
			}
			else if((tp_strcmp(machine_num,"HIG")) == 0)
			{
				delay_ms(5000);										
			}

		}
	}
}

/*****************************************************************************
**                            End Of File
*****************************************************************************/
