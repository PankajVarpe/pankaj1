/*****************************************************************************
 *   uarttest.c:  main C entry file for NXP LPC17xx Family Microprocessors
 *
 *   Copyright(C) 2009, NXP Semiconductor
 *   All rights reserved.
 *
 *   History
 *   2009.05.27  ver 1.00    Prelimnary version, first Release
 *
******************************************************************************/
#include "lpc17xx.h"
#include "type.h"
#include "uart.h"

#include "string.h"

extern volatile uint32_t UART3Count;
extern volatile uint8_t UART3Buffer[BUFSIZE];
extern volatile uint32_t UART2Count;
extern volatile uint8_t UART2Buffer[BUFSIZE];
extern volatile uint32_t UART1Count;
extern volatile uint8_t UART1Buffer[BUFSIZE];
extern volatile uint32_t UART0Count;
extern volatile uint8_t UART0Buffer[BUFSIZE];

void send_command(unsigned char *data);
int getreply(void);
void delay_ms(int a),mode(),init_esp(),connectrouter(),mux(),server(),senddata1(),senddata2(),clear_sting(unsigned char *str, unsigned int val ),ledon(),receivedata();
signed int tp_strcmp( unsigned char *s1, unsigned char *s2);
unsigned char string_rec[20];
unsigned char machine_num[50];
void senddata(void);

/*****************************************************************************
**   Main Function  main()
This program has been test on Keil LPC1700 board.
*****************************************************************************/
int main (void)
{
	unsigned short int i;
	SystemInit();

    LPC_GPIO0->FIODIR |= (1<<4); 
	LPC_GPIO0->FIOCLR |= (1<<4); 
 
  	init_esp();
  
  	UARTSend( 0, "echo completed", 15);
  
 //	connectrouter();
//	UARTSend( 0, "router completed", 15);
	mode();


	mux();
//	UARTSend( 1, "AT+CIFSR", sizeof("AT+CIFSR"));	
//	delay_ms(200);

//	server();
	UARTSend( 0, (uint8_t *)UART1Buffer, UART1Count );
	
	
	i=getreply();  	

	delay_ms(100);

 		while (1) 
 		 {				/* Loop forever */

		 

  			


			switch(i) {
					case 1  :
										ledon();
										i=getreply();
										continue;
   				 							 
	
					case 2  :
										senddata1();
									//	receivedata();
										i=getreply();
										continue;

					case 3  :
										senddata2();
									//	receivedata();
										i=getreply();
										continue;
					}		
	}												  
}

void connectrouter(){
	unsigned short int i,j;
	unsigned char data_rcv[3];
 
//  	unsigned char s;
  	send_command("AT+CWJAP=\"D-Link_DIR-600M\",\"\"\r\n");
  	delay_ms(100);

	UARTSend( 0, (uint8_t *)UART1Buffer, UART1Count );
	i=0;

	while(UART1Buffer[i++] != 'O');
//	data_rcv[0]='O';
//	data_rcv[1]='K';
//	
//	data_rcv[2]='\0';
	i--;
	for(j=0;j<2;j++)
	{
	 	data_rcv[j]= UART1Buffer[i++];
	}
	data_rcv[j]='\0';
	UARTSend( 0, (uint8_t *)data_rcv, sizeof(data_rcv) );
	if((tp_strcmp((uint8_t *)data_rcv,"OK")) == 0)
			{
				UARTSend( 0, "ROUTER completed", 5 );
				//	server();	
			}
		else
		{
			UARTSend( 0, "ROUTER unsuccess", 9 );
		}
  	send_command("AT+CIFSR\r\n");
   	delay_ms(100);
	return;
}				

void mode(){
	unsigned short int i,j;
	unsigned char data_rcv[3];
 
//  	unsigned char s;
 // 	send_command("AT+CWMODE=3");
	UARTSend( 1, "AT+CWMODE=2", sizeof("AT+CWMODE=2"));	
  	delay_ms(100);
	UARTSend( 0, (uint8_t *)UART1Buffer, UART1Count );
	i=0;

	while(UART1Buffer[i++] != 'O');
//	data_rcv[0]='O';
//	data_rcv[1]='K';
//	
//	data_rcv[2]='\0';
	i--;
	for(j=0;j<2;j++)
	{
	 	data_rcv[j]= UART1Buffer[i++];
	}
	data_rcv[j]='\0';
	UARTSend( 0, (uint8_t *)data_rcv, sizeof(data_rcv) );
	if((tp_strcmp((uint8_t *)data_rcv,"OK")) == 0)
			{
				UARTSend( 0, "SERVER", 7 );
				//	server();	
			}
		else
		{
			UARTSend( 0, "FAILED AS SERVER", 15 );
		}
   
	return;
}								  				  

void init_esp(){
	unsigned short int i,j;
	unsigned char data_rcv[3];
	clear_sting(UART1Buffer,UART1Count);
	UARTInit(0, 9600); /* uart0 */
  	UARTInit(1, 9600);	/* baud rate setting for esp */
   	UARTSend( 0, "wait", 4);
	UARTSend( 1, "ATE0\r\n", sizeof("ATE0\r\n"));	
 	delay_ms(100);
	clear_sting(UART1Buffer,UART1Count);
	UARTSend( 0, (uint8_t *)UART1Buffer, UART1Count );

	UARTSend( 1, "AT\r\n", sizeof("AT\r\n"));	
 	delay_ms(100); 
	UARTSend( 0, (uint8_t *)UART1Buffer, UART1Count );



	UARTSend( 0, (uint8_t *)UART1Buffer, UART1Count );
	i=0;

	while(UART1Buffer[i++] != 'O');
//	data_rcv[0]='O';
//	data_rcv[1]='K';
//	
//	data_rcv[2]='\0';
	i--;
	for(j=0;j<2;j++)
	{
	 	data_rcv[j]= UART1Buffer[i++];
	}
	data_rcv[j]='\0';
	UARTSend( 0, (uint8_t *)data_rcv, sizeof(data_rcv) );
	if((tp_strcmp((uint8_t *)data_rcv,"OK")) == 0)
		{
			UARTSend( 0, "Initialiize", 5 );	
		}
		else
		{
			UARTSend( 0, "Initialiize unsuccess", 9 );
		}
	return;
}

void mux(){
	unsigned short int i,j;
	unsigned char data_rcv[3];
	clear_sting(UART1Buffer,UART1Count);
	UARTSend( 1, "AT+CIPMUX=1\r\n", sizeof("AT+CIPMUX=1\r\n"));
	delay_ms(300);
	

	UARTSend( 0, (uint8_t *)UART1Buffer, UART1Count );
	i=0;

	while(UART1Buffer[i++] != 'O');
	i--;
	for(j=0;j<2;j++)
	{
	 	data_rcv[j]= UART1Buffer[i++];
	}
	data_rcv[j]='\0';
	UARTSend( 0, (uint8_t *)data_rcv, sizeof(data_rcv) );
	if((tp_strcmp((uint8_t *)data_rcv,"OK")) == 0)
			{
				UARTSend( 0, "Mux completed", 13);
					server();	
			}
		else
		{
			mux();
		}
	return;	
}
void server(){
	unsigned short int i,j;
	unsigned char data_rcv[3];
	clear_sting(UART1Buffer,UART1Count);
	UARTSend( 1, "AT+CIPSERVER=1,139\r\n", sizeof("AT+CIPSERVER=1,139\r\n"));
//	AT+CIPSERVER=1,139
 	delay_ms(200);
	UARTSend( 0, (uint8_t *)UART1Buffer, UART1Count );
	i=0;

	while(UART1Buffer[i++] != 'O');
//	data_rcv[0]='O';
//	data_rcv[1]='K';
//	
//	data_rcv[2]='\0';
	i--;
	for(j=0;j<2;j++)
	{
	 	data_rcv[j]= UART1Buffer[i++];
	}
	data_rcv[j]='\0';
	UARTSend( 0, (uint8_t *)data_rcv, sizeof(data_rcv) );
	if((tp_strcmp((uint8_t *)data_rcv,"OK")) == 0)
			{
				UARTSend( 0, "set as Server completed", 23 );
				return;	
			//	getreply();	
			}
		else
		{
			UARTSend( 0, "server unsuccess", 16 );
			server();
		}
	
}

void send_command(unsigned char *data){
	UARTSend( 1, data, sizeof(data) );
//	getreply();
	return;	
}

void ledon(){

	clear_sting(UART1Buffer,UART1Count);
	UARTSend( 0, "LED1 ON\r\n", sizeof("LED1 ON\r\n"));

	LPC_GPIO0->FIOSET |= (1<<4); 
	return;
}

void senddata1(){
   	unsigned short int i,j;
	unsigned char data_rcv[3];
	delay_ms(200);
	clear_sting(UART1Buffer,UART1Count);
	clear_sting(string_rec,sizeof(string_rec));

	UART1Count=0; 
//	delay_ms(10000);
	UARTSend( 0, "sending data", 13);
	UARTSend( 1, "AT+CIPSEND=0,5\r\n", sizeof("AT+CIPSEND=0,5\r\n"));
	delay_ms(800);


	UARTSend( 0, (uint8_t *)UART1Buffer, UART1Count );
	i=0;

	while(UART1Buffer[i++] != '>');


	
	i--;
	for(j=0;j<1;j++)
	{
	 	data_rcv[j]= UART1Buffer[i++];
	}
	data_rcv[j]='\0';
	UARTSend( 0, (uint8_t *)data_rcv, sizeof(data_rcv) );
	if((tp_strcmp((uint8_t *)data_rcv,">")) == 0)
			{
				UARTSend( 0, "DATA SENT", 9);
		//		UARTSend( 0, "DATA SENT", 20 );
				UARTSend( 1, "START\r\n", sizeof("START\r\n"));
				getreply();
			}
		else
		{
			UARTSend( 0, "DATA NOT SENT to client", 23 );
			getreply();
		}
	return;
}
void senddata2(){
   	unsigned short int i,j;
	unsigned char data_rcv[3];
	delay_ms(200);
	clear_sting(UART1Buffer,UART1Count);
	clear_sting(string_rec,sizeof(string_rec));

	UART1Count=0; 
//	delay_ms(10000);
	UARTSend( 0, "sending data", 13);
	UARTSend( 1, "AT+CIPSEND=1,5\r\n", sizeof("AT+CIPSEND=0,5\r\n"));
	delay_ms(800);


	UARTSend( 0, (uint8_t *)UART1Buffer, UART1Count );
	i=0;

	while(UART1Buffer[i++] != '>');


	
	i--;
	for(j=0;j<1;j++)
	{
	 	data_rcv[j]= UART1Buffer[i++];
	}
	data_rcv[j]='\0';
	UARTSend( 0, (uint8_t *)data_rcv, sizeof(data_rcv) );
	if((tp_strcmp((uint8_t *)data_rcv,">")) == 0)
			{
				UARTSend( 0, "DATA SENT", 9);
		//		UARTSend( 0, "DATA SENT", 20 );
				UARTSend( 1, "START\r\n", sizeof("START\r\n"));
				getreply();
			}
		else
		{
			UARTSend( 0, "DATA NOT SENT to client", 23 );
			getreply();
		}
	return;
}

signed int tp_strcmp( unsigned char *s1, unsigned char *s2)
	{
   		for (; *s1 == *s2; s1++, s2++)
      		if (*s1 == '\0')
         	return(0);
   		return((*s1 < *s2) ? -1: 1);
	}


void clear_sting(unsigned char *str, unsigned int val ){
	int i = 0 ;
     for( i = 0 ; i < val ; i++ )
     {
          str[i] = '\0' ;
     }
	 return ;
}

int getreply(){
	unsigned short int i,j;
	unsigned char data_rcv[6];
	UART0Count=0;
	clear_sting(UART0Buffer,25);
 	while (1) 
 	 {				/* Loop forever */
 	 delay_ms(300);

  	UARTSend( 0, (uint8_t *)UART0Buffer, UART0Count );
	i=0;

	while(UART0Buffer[i++] != 'S');

	i--;
	for(j=0;j<7;j++)
	{
	 	data_rcv[j]= UART0Buffer[i++];
	}
	data_rcv[j]='\0';
	UARTSend( 0, (uint8_t *)data_rcv, sizeof(data_rcv) );

	if((tp_strcmp((uint8_t *)data_rcv,"START:1")) == 0)
			{
	
				return 1;
			
			}
		else if((tp_strcmp((uint8_t *)data_rcv,"START:2")) == 0)
			{
			 	return 2;
			
			}

		else if((tp_strcmp((uint8_t *)data_rcv,"START:3")) == 0)
			{
			 	return 3;
			
			}
  	}

}

void receivedata(){
	unsigned short int i,j;
	unsigned char data_rcv[6];
	UART0Count=0;
	clear_sting(UART1Buffer,50);
 	while (1) 
 	 {				/* Loop forever */
 	 delay_ms(300);

  	UARTSend( 0, (uint8_t *)UART1Buffer, UART0Count );
	i=0;

	while(UART1Buffer[i++] != 'L');

	i--;
	for(j=0;j<7;j++)
	{
	 	data_rcv[j]= UART1Buffer[i++];
	}
	data_rcv[j]='\0';
	UARTSend( 0, (uint8_t *)data_rcv, sizeof(data_rcv) );

	if((tp_strcmp((uint8_t *)data_rcv,"LED2 ON")) == 0){
		   
		   UARTSend( 0, (uint8_t *)data_rcv, sizeof((uint8_t *)data_rcv) );
			return;	
		}	
  	}
	

}


void delay_ms(int a){
	int i,j;
	for(i = 0 ; i < a ; i++ )
	{
		for(j = 0 ; j < 10000 ; j++ ) ;
	}
	return ;
}

/*****************************************************************************
**                            End Of File
*****************************************************************************/
