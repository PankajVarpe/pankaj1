/*****************************************************************************
 *   uarttest.c:  main C entry file for NXP LPC17xx Family Microprocessors
 *
 *   Copyright(C) 2009, NXP Semiconductor
 *   All rights reserved.
 *
 *   History
 *   2009.05.27  ver 1.00    Prelimnary version, first Release
 *
******************************************************************************/
#include "lpc17xx.h"
#include "uart.h"
#include "stdio.h"
#include "stdutils.h"
#include "gpio.h"
#include "extintr.h"
#include "timer.h"
#include <string.h>


#define SBIT_WordLenght    0x00u
#define SBIT_DLAB          0x07u
#define SBIT_FIFO          0x00u
#define SBIT_RxFIFO        0x01u
#define SBIT_TxFIFO        0x02u

#define SBIT_RDR           0x00u
#define SBIT_THRE          0x05u

#define LED1      P2_0
#define LED2      P2_1

#define clkpin P2_12
#define dataPin P0_4

extern volatile uint32_t UART3Count;
extern volatile uint8_t UART3Buffer[BUFSIZE];
extern volatile uint32_t UART2Count;
extern volatile uint8_t UART2Buffer[BUFSIZE];
extern volatile uint32_t UART1Count;
extern volatile uint8_t UART1Buffer[BUFSIZE];
extern volatile uint32_t UART0Count;
extern volatile uint8_t UART0Buffer[BUFSIZE];

void decodedata(void);
void clockISR(void);
void DECI_ASCII( int  deci ,unsigned  char *string );
unsigned char digitalRead(char dataPin);
unsigned int getPrescalarForUs(uint8_t timerPclkBit);
unsigned char integer(float i);
void Long_ASCII( long  deci ,unsigned  char *string );
void display(float result);
	float previous = 0;
char result[150] = "";
unsigned char ASCII_num[]= { '0','1','2','3','4','5','6','7','8','9' };
//Milliseconds to wait until starting a new value
//This can be a different value depending on which flavor caliper you are using.
const int cycleTime = 32; 

unsigned volatile int clockFlag = 0; 

long now = 0;
long lastInterrupt = 0;
long value = 0;

float finalValue = 0;
float previousValue = 0;

int newValue = 0;
int sign = 1;
int currentBit = 1;





/*****************************************************************************
**   Main Function  main()
This program has been test on Keil LPC1700 board.
*****************************************************************************/
int main (void)
{
	char ch;
	char buffer[250];
	char a[64];
	unsigned char vOut;
    SystemInit();
    TIMER_Init(0,100000);     // 100000us means 100ms
	TIMER_Start(0);
	UARTInit(0, 9600);  // Initialize the UART0 for 9600 baud rate
			
    GPIO_PinDirection(LED1,OUTPUT);        /* Configure the pins as Output to blink the Leds*/
    GPIO_PinDirection(LED2,OUTPUT);
	GPIO_PinDirection(clkpin,INPUT);        /* Configure the pins as input to clock*/

    EINT_AttachInterrupt(EINT2,clockISR,RISING);   /* myExtIntrIsr_0 will be called by EINT2_IRQHandler */

    while(1)
    {		
		if(newValue) 
		{
				if(finalValue != previousValue) {			 //compare previous and present value
					previousValue = finalValue;
			//		sprintf(buffer, "%f", finalValue); 
			//		UARTSend( 0, buffer,9);		
					display(finalValue);
			 }
				newValue = 0;
		}
			
		 //The ISR Can't handle the arduino command millis()
		 //because it uses interrupts to count. The ISR will 
		 //set the clockFlag and the clockFlag will trigger 
		 //a call the decode routine outside of an ISR.
		 if(clockFlag == 1)
		 {
				clockFlag = 0;
				decodedata();
		 }
    }       														  
}


/* decode caliper value	*/
void decodedata(void){
   unsigned char dataIn,vOut;
   int x;
   dataIn=GPIO_PinRead(dataPin);	// read data from digital read pin
	now=TIMER_GetTime(0);	   		// get present time of timer count by deviding 1000   
   if(now-lastInterrupt > 32)						  //checking wether its >32ms
   {
    
     finalValue = (value * sign) / 100.00;			 // calculation of caliper value
     currentBit = 0;
	 lastInterrupt=0;
     value = 0;
     sign = 1;
     newValue = 1;       
   } 
   else if (currentBit < 16 )
   { 

     if (dataIn == 0)
     {
       if (currentBit < 16) {
          value |= 1 << currentBit;					   // calculate value of caliper 
       }  
       else if (currentBit == 20) {
          sign = -1;
       }
               
     }
     
     currentBit++;
   }
   lastInterrupt = now;
}

/* when external interrupt occurs*/
void clockISR(){
	clockFlag = 1; 
}

void display(float result){
		char buffer[100];
	if(result!=previous){
		previous=result;
		sprintf(buffer, "%f", result); 
		UARTSend( 0, buffer, 9);
	}
	else
	{
		return;
	}
	return;

}
